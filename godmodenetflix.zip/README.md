### Disclaimer: Netflix is a registered trademark and has no affiliation to this bookmarklet.

[Click here or the image to get it!](http://bit2pixel.com/netflix-god-mode/)

[![Alt text](https://raw.githubusercontent.com/bit2pixel/netflix-god-mode-bookmarklet/master/netflix-god-mode.png "Click to get it!")](http://bit2pixel.com/netflix-god-mode/)
